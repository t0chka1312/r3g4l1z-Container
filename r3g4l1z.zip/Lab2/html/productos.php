<?php include("menu.php"); ?>
<div class="container">
  <h2>Nuestros Regalices</h2>
  <p>¡Descubre los diseños más oscuros y deliciosos subidos por nuestros fieles seguidores!</p>
  <div class="grid">
    <div>
      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Liquorice_wheels.jpg/500px-Liquorice_wheels.jpg" class="producto">
      <p>Regaliz Mix Demoníaco</p>
    </div>
    <div>
      <img src="https://www.marialunarillos.com/media/catalog/product/cache/babc9c3930426724bed95a50193e0e01/g/o/gominolas-de-az_car-espirales-de-regaliz-de-fresa-_250-uds_---fini.jpg" class="producto">
      <p>Clásico Regaliz Oscuro</p>
    </div>
    <div>
      <img src="https://cdn.milenio.com/uploads/media/2021/03/02/de-que-esta-hecho-el-1_0_0_1200_747.jpg" class="producto">
      <p>Regaliz Sangriento</p>
    </div>
    <div>
      <img src="https://i.pinimg.com/originals/ba/de/0f/bade0fd5b0032ac1f1596408fea6d7ae.jpg" class="producto">
      <p>Gominola Explosiva</p>
    </div>
  </div>
</div>
