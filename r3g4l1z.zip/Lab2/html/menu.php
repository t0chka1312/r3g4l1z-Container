<link rel="stylesheet" href="css/style.css">
<nav>
  <a href="index.php">Inicio</a>
  <a href="productos.php">Productos</a>
  <a href="upload.php">Subir diseño</a>
  <a href="contacto.php">Contacto</a>
  <a href="login.php">Login</a>
</nav>
